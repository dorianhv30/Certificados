﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SIGDAI.Models
{
    /// <summary>
    /// Modelo de datos para el registro de horas
    /// </summary>
    public class RegistroHorasViewModel
    {
        public int IdRegistro { get; set; }
        [Required]              
        public int IdAsignado { get; set; }

        [Display(Name = "Actividad", Description = "Nombre del proyecto o actividad asignada")]
        [Required(ErrorMessage = "Debe seleccionar una actvividad o proyecto")]
        [UIHint("CustomGridForeignKey")]
        public int IdProyecto { get; set; }

        [Display(Name = "SubActividad", Description = "Nombre de la SubActividad realizada")]
        [Required(ErrorMessage = "Debe seleccionar una SubActividad")]
        [UIHint("CustomGridForeignKey")]
        public int IdEtapa { get; set; }
        [Display(Name = "Descripción", Description = "Descripción de la actividad realizada")]
        [Required(ErrorMessage = "Ingresar una descripción de la actividad realizada")]
        public string Descripcion { get; set; }
        [Display(Name = "Id Project", Description = "Id de la tarea en Project (Si aplica)")]
        public int? IdProject { get; set; }
        [Display(Name = "Fecha", Description = "Fecha de la actividad realizada")]
        [Required(ErrorMessage = "Debe seleccionar una fecha")]
        public System.DateTime Fecha { get; set; }
        [Display(Name = "Horas", Description = "Cantidad de horas laboradas")]
        [Required(ErrorMessage = "Debe ingresar la cantidad de horas laboradas")]
        public decimal Horas { get; set; }
        public decimal? HorasAdicionales { get; set; }
        public int Estado { get; set; }
        [Display(Name = "Comentario de rechazo", Description = "Cantidad de horas laboradas")]
        public string ComentarioRechazo { get; set; }

    }
}