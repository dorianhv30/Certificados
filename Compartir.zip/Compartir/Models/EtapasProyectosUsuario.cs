﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SIGDAI.Models
{
    /// <summary>
    /// Modelo para obtener las etapas ligadas a un proyecto
    /// </summary>
    public class EtapasProyectosUsuario
    {
        public int IdProyecto { get; set; }

        [Display(Name = "SubActividad", Description = "Nombre de la subatividad a registrar")]
        [Required(ErrorMessage = "Debe seleccionar una subactividad")]
        public string NombreEtapa { get; set; }
    }
}