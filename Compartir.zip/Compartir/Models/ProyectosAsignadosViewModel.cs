﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SIGDAI.Models
{
    /// <summary>
    /// Modelo de datos para los proyectos asignados
    /// </summary>
    public class ProyectosAsignadosViewModel
    {
        public int IdAsignacion { get; set; }
        public int IdProyecto { get; set; }

        [Display(Name = "Actividad", Description = "Nombre del proyecto o actividad asignada")]
        [Required(ErrorMessage = "Debe seleccionar una actvividad o proyecto")]
        public string NombreProyecto { get; set; }
        public int IdUsuario { get; set; }
        public int? Estado { get; set; }
        public int HorasAsignadas { get; set; }

    }
}